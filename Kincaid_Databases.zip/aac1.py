from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import loads, dumps

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@127.0.0.1:27017/AAC' % (username, password))
        self.database = self.client['AAC']

    def create(self, data):
        # Checks to see if the data is null or empty and returns false in either case
        if data is not None:
            if data:
                self.database.animals.insert_one(data)
                return True
        else:
            return False
     
       #R method in CRUD
    def read(self, data):
        # Checks to see if the data is null or empty and returns exception in either case
        if data is not None:
                return self.database.animals.find(data,{"_id":False})
        else:
            exception = "Nothing to search, because data parameter is empty"
            return exception

      #U method in CRUD
    def update(self, data, change):
	#makes a new record, finds the data and dumps it to a JSON file by using json utility 
        if data is not None:
        	return self.database.animals.update(data,{ "$set": change}) # data and change are dictionaries
        else:
            print('Nothing to update, because data parameter is empty')
            return False

     #D method in CRUD
    def delete(self, data):
	#makes a new record, finds the data and dumps it to a JSON file by using json utility
        if data is not None:
            return self.database.animals.delete_one(data) # data is dictionary
        else:
            print('Nothing to delete, because data parameter is empty')
            return False

