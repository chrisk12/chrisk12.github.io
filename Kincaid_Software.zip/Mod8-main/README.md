# Mod8
Software testing module 8 repo
To ensure that code, program, or software is functional and secure, always double check your work and have someone else review it. This is the best way to ensure that the code does as intended.
The best way to interpret user needs and incorporate them into the program is by being fully aware of the requirements down to every detail. Once you fully understand the requirements, write the code, test for functionality, and review the requirements asked from the software. 
The best way to design software is to follow the SDLC. Plan, get user requirements, write code, test the code, get user feedback, and then tweak the software based off user critiques, then release. 
