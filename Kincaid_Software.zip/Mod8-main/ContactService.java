/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test_module3;

/**
 *
 * @author kkris
 */
import java.util.ArrayList;

public class ContactService {
   /* List of contacts for ContactService */
   private ArrayList<Contact> contactList;

   /* constructor for Contact service */
   public ContactService() {
       contactList = new ArrayList<>();
   }


   public boolean add(Contact contact) {
       /* determines if current contact exists */
       boolean currentContact = false;
       for (Contact c : contactList) {
           if (c.equals(contact)) {
        	   currentContact = true;
           }
       }
       /* if currentContact is not true, then add the new contact, and print out that it was done successfully, otherwise prints that contact already exists*/
       if (!currentContact) {
           contactList.add(contact);
           System.out.println("Contact has been added");
           return true;
       } else {
           System.out.println("Contact already exists");
           return false;
       }
   }

   /* Removes a contact with a given contact ID if it is in the contacts list */
   public boolean remove(String contactID) {
       for (Contact c : contactList) {
           if (c.getContactID().equals(contactID)) {
               contactList.remove(c);
               System.out.println("Contact has been removed");
               return true;
           }
       }
       System.out.println("Contact not present. Please check the contact ID and try again.");
       return false;
   }

   /* Updates the contact of the specified contactID (updates first, last, phone, and address.) */
   public boolean update(String contactID, String firstName, String lastName, String phone, String address) {
      /* for each new contact in ContactList, update the variable if it is not blank */
       for (Contact c : contactList) {
           if (c.getContactID().equals(contactID)) {
               if (!firstName.equals(""))
                   c.setFirstName(firstName);
               
               if (!lastName.equals(""))
                   c.setLastName(lastName);
               
               if (!phone.equals(""))
            	   c.setPhone(phone);
               
               if (!address.equals(""))
                   c.setAddress(address);
               System.out.println("Contact has been updated.");
               return true;
           }
       }
       System.out.println("Contact does not exist. Please check the contact ID and try again");
       return false;
   }

}
