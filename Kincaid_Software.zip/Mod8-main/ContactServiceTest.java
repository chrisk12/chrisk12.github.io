/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test_module3;


import org.junit.Test;
import static org.junit.Assert.*;
/**
 *
 * @author kkris
 */
public class ContactServiceTest {

   /* testing the add method to work fine, when details provided should work */
   @Test
   public void testMethodAddPass() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
       assertEquals(true, cs.add(c1));
       Contact c2 = new Contact("02", "Jimmy", "Carter","2222222222", "2nd Street");
       assertEquals(true, cs.add(c2));
       Contact c3 = new Contact("03", "Will", "Williams","3333333333", "3rd Street");
       assertEquals(true, cs.add(c3));
   }

   /* testing the add method to work fine,when details provided should not work */
   @Test
   public void testMethodAddFail() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
       assertEquals(true, cs.add(c1));
       assertEquals(false, cs.add(c1));
       Contact c2 = new Contact("02", "Jimmy", "Carter","2222222222", "2nd Street");
       assertEquals(true, cs.add(c2));
       Contact c3 = new Contact("03", "Will", "Williams","3333333333", "3rd Street");
       assertEquals(true, cs.add(c3));
   }

   /* test the delete method */
   @Test
   public void testMethodDeletePass() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
       assertEquals(true, cs.add(c1));
       Contact c2 = new Contact("02", "Jimmy", "Carter","2222222222", "2nd Street");
       assertEquals(true, cs.add(c2));
       Contact c3 = new Contact("03", "Will", "Williams","3333333333", "3rd Street");
       assertEquals(true, cs.add(c3));

       assertEquals(true, cs.remove("03"));
       assertEquals(true, cs.remove("02"));
   }

   /* test the delete method */
   @Test
   public void testMethodDeleteFail() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
       assertEquals(true, cs.add(c1));
       Contact c2 = new Contact("02", "Jimmy", "Carter","2222222222", "2nd Street");
       assertEquals(true, cs.add(c2));
       Contact c3 = new Contact("03", "Will", "Williams","3333333333", "3rd Street");
       assertEquals(true, cs.add(c3));

       assertEquals(false, cs.remove("04"));
       assertEquals(true, cs.remove("02"));
   }

   /* test the update method */
   @Test
   public void testUpdatePass() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
       assertEquals(true, cs.add(c1));
       Contact c2 = new Contact("02", "Jimmy", "Carter","2222222222", "2nd Street");
       assertEquals(true, cs.add(c2));
       Contact c3 = new Contact("03", "Will", "Williams","3333333333", "3rd Street");
       assertEquals(true, cs.add(c3));

       assertEquals(true, cs.update("03", "Sean", "Paul","1111111111", ""));
       assertEquals(true, cs.update("02", "Jimmy", "Bush","1111111111", "124 LA ST"));
   }

   /* test the update method */
   @Test
   public void testUpdateFail() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
       assertEquals(true, cs.add(c1));
       Contact c2 = new Contact("02", "Jimmy", "Carter","2222222222", "2nd Street");
       assertEquals(true, cs.add(c2));
       Contact c3 = new Contact("03", "Will", "Williams","3333333333", "3rd Street");
       assertEquals(true, cs.add(c3));

       assertEquals(false, cs.update("04", "Jacob", "Stone","4444444444", ""));
       assertEquals(true, cs.update("02", "Howard", "Ludema","1111111111", "2nd Street"));
   }

}