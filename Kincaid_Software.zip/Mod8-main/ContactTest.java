/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test_module3;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kkris
 */
public class ContactTest {

    /**
     * Test of getContactID method, of class Contact.
     */
    @Test
    public void testGetContactID() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
        String expResult = "01";
        String result = c1.getContactID();
        assertEquals(expResult, result);
    }

    /**
     * Test of getFirstName method, of class Contact.
     */
    @Test
    public void testGetFirstName() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
        String expResult = "Jonathan";
        String result = c1.getFirstName();
        assertEquals(expResult, result);
    }

    /**
     * Test of getLastName method, of class Contact.
     */
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
        String expResult = "Baker";
        String result = c1.getLastName();
        assertEquals(expResult, result);
    }
    /**
     * Test of getPhone method, of class Contact.
     */
    @Test
    public void testGetPhone() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
        String expResult = "1111111111";
        String result = c1.getPhone();
        assertEquals(expResult, result);
    }

    /**
     * Test of getAddress method, of class Contact.
     */
    @Test
    public void testGetAddress() {
       ContactService cs = new ContactService();
       Contact c1 = new Contact("01", "Jonathan", "Baker","1111111111", "1st Street");
        String expResult = "1st Street";
        String result = c1.getAddress();
        assertEquals(expResult, result);
    }
    
}

