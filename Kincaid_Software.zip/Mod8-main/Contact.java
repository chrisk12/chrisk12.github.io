/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test_module3;

/**
 *
 * @author kkris
 */
/*Class for Contact info*/
public class Contact {
	/*Unique contactID, cannot be longer than 10 characters*/
	private String contactID;
	
	/*String for first name, cannot be longer than 10 characters*/
	private String firstName;
	
	/*String for last name, cannot be longer than 10 characters*/
	private String lastName;
	
	/*String for phone number, must be exactly 10 digits*/
	private String phone;
	
	/*String for address, cannot be longer than 30 characters*/
	private String address;
	
	 /*Constructor for updating Contacts*/
		public Contact(String contactID, String firstName, String lastName, String phone, String address) {
			
			if(contactID!=null && contactID.length()<=10) {
				this.contactID = contactID;
			} else {
				System.out.println("Please provide a valid contactID.");
			}
			
			if(firstName!=null && firstName.length()<=10) {
				this.firstName = firstName;
			} else {
				System.out.println("Please provide a valid first name.");
			}
			
			if(lastName!=null && lastName.length()<=10) {
				this.lastName = lastName;
			} else {
				System.out.println("Please provide a valid last name.");
			}
			
			if(phone!=null && phone.length()==10) {
				this.phone = phone;
			} else { 
				System.out.println("Please provide a valid phone number.");
			}
			
			if(address!=null && address.length()<=30) {
				this.address = address;
			} else { 
				System.out.println("Please provide a valid address.");
			}
			

		}
		
		/* getter and setters*/
		public String getContactID() {
			return contactID;
		}
	
		/*No setter for contactID, cannot be updated according to software requirements*/
		
		/*firstName getter*/
		public String getFirstName() {
			return firstName;
		}
		/*firstName setter*/
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		/*lastName getter*/
		public String getLastName() {
			return lastName;
		}
		
		/*lastName setter*/
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		
		/*phone getter*/
		public String getPhone() {
			return phone;
		}
		
		/*phone setter*/
		public void setPhone(String phone) {
			this.phone = phone;
		}
		
		/* address getter*/
		public String getAddress() {
			return address;
		}
		/*address setter*/
		public void setAddress(String address) {
			this.address = address;
		}
		   
}
